'use client';

import { motion } from 'framer-motion';
import Link from 'next/link';
import { ArrowRight } from 'lucide-react';
import { cn } from '@/lib/utils';

interface SectionHeaderProps {
  title: string;
  subtitle?: string;
  href?: string;
  hrefLabel?: string;
  className?: string;
}

export function SectionHeader({
  title,
  subtitle,
  href,
  hrefLabel = 'View all',
  className,
}: SectionHeaderProps) {
  return (
    <div
      className={cn(
        'mb-8 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end',
        className
      )}
    >
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
      >
        {subtitle && (
          <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-gold-500">
            {subtitle}
          </p>
        )}
        <h2 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
          {title}
        </h2>
      </motion.div>
      {href && (
        <Link
          href={href}
          className="group flex items-center gap-1.5 text-sm font-semibold text-brand transition-colors hover:text-gold-500"
        >
          {hrefLabel}
          <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
        </Link>
      )}
    </div>
  );
}
