'use client';

import { useEffect, useState } from 'react';
import { Clock } from 'lucide-react';

interface CountdownTimerProps {
  hours?: number;
  className?: string;
}

export function CountdownTimer({ hours = 12, className }: CountdownTimerProps) {
  const [timeLeft, setTimeLeft] = useState({
    hours: hours,
    minutes: 0,
    seconds: 0,
  });

  useEffect(() => {
    const target = new Date();
    target.setHours(target.getHours() + hours);
    target.setMinutes(0, 0);

    const interval = setInterval(() => {
      const diff = target.getTime() - Date.now();
      if (diff <= 0) {
        setTimeLeft({ hours: 0, minutes: 0, seconds: 0 });
        clearInterval(interval);
        return;
      }
      const h = Math.floor(diff / (1000 * 60 * 60));
      const m = Math.floor((diff / (1000 * 60)) % 60);
      const s = Math.floor((diff / 1000) % 60);
      setTimeLeft({ hours: h, minutes: m, seconds: s });
    }, 1000);

    return () => clearInterval(interval);
  }, [hours]);

  const pad = (n: number) => n.toString().padStart(2, '0');

  return (
    <div className={`flex items-center gap-2 ${className ?? ''}`}>
      <Clock className="h-4 w-4 text-gold-500" />
      <div className="flex items-center gap-1.5">
        <span className="rounded-md bg-brand px-2 py-1 text-sm font-bold text-brand-foreground tabular-nums">
          {pad(timeLeft.hours)}
        </span>
        <span className="font-bold text-brand">:</span>
        <span className="rounded-md bg-brand px-2 py-1 text-sm font-bold text-brand-foreground tabular-nums">
          {pad(timeLeft.minutes)}
        </span>
        <span className="font-bold text-brand">:</span>
        <span className="rounded-md bg-brand px-2 py-1 text-sm font-bold text-brand-foreground tabular-nums">
          {pad(timeLeft.seconds)}
        </span>
      </div>
    </div>
  );
}
