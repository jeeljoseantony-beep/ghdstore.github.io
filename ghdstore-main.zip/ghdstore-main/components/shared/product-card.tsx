'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { Heart, ShoppingCart, Zap } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Rating } from '@/components/shared/rating';
import { useCart } from '@/components/providers/cart-provider';
import { cn } from '@/lib/utils';
import type { Product } from '@/lib/types';
import { useToast } from '@/hooks/use-toast';

interface ProductCardProps {
  product: Product;
  index?: number;
}

export function ProductCard({ product, index = 0 }: ProductCardProps) {
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const { toast } = useToast();
  const wished = isInWishlist(product.id);

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    addToCart({
      id: product.id,
      name: product.name,
      price: product.price,
      oldPrice: product.oldPrice,
      image: product.image,
      category: product.category,
    });
    toast({
      title: 'Added to cart',
      description: product.name,
    });
  };

  const handleBuyNow = () => {
    addToCart(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        oldPrice: product.oldPrice,
        image: product.image,
        category: product.category,
      },
      1
    );
    window.location.href = '/checkout';
  };

  return (
    <motion.div
      initial={{ opacity: 0, y: 20 }}
      whileInView={{ opacity: 1, y: 0 }}
      viewport={{ once: true, margin: '-50px' }}
      transition={{ duration: 0.4, delay: index * 0.05 }}
      className="group relative flex flex-col overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
    >
      {/* Image */}
      <Link href={`/product/${product.slug}`} className="relative block aspect-square overflow-hidden bg-muted">
        <Image
          src={product.image}
          alt={product.name}
          fill
          sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 25vw"
          className="object-cover transition-transform duration-500 group-hover:scale-110"
        />
        {/* Badges */}
        <div className="absolute left-3 top-3 flex flex-col gap-1.5">
          {discount > 0 && (
            <span className="rounded-full bg-red-500 px-2.5 py-1 text-xs font-bold text-white shadow-md">
              -{discount}%
            </span>
          )}
          {product.isFlashDeal && (
            <span className="flex items-center gap-1 rounded-full bg-gold-400 px-2.5 py-1 text-xs font-bold text-black shadow-md">
              <Zap className="h-3 w-3 fill-current" />
              Flash
            </span>
          )}
        </div>
        {/* Wishlist */}
        <button
          onClick={(e) => {
            e.preventDefault();
            toggleWishlist(product.id);
            toast({
              title: wished ? 'Removed from wishlist' : 'Added to wishlist',
              description: product.name,
            });
          }}
          className="absolute right-3 top-3 flex h-9 w-9 items-center justify-center rounded-full bg-white/90 shadow-md backdrop-blur transition-all hover:scale-110 dark:bg-black/60"
          aria-label="Toggle wishlist"
        >
          <Heart
            className={cn(
              'h-4.5 w-4.5 transition-colors',
              wished ? 'fill-red-500 text-red-500' : 'text-foreground'
            )}
          />
        </button>
      </Link>

      {/* Content */}
      <div className="flex flex-1 flex-col p-4">
        <Link href={`/category/${product.categorySlug}`}>
          <span className="text-xs font-medium uppercase tracking-wide text-muted-foreground hover:text-brand">
            {product.category}
          </span>
        </Link>
        <Link href={`/product/${product.slug}`} className="mt-1">
          <h3 className="line-clamp-2 text-sm font-semibold leading-snug text-foreground transition-colors hover:text-brand">
            {product.name}
          </h3>
        </Link>
        <div className="mt-2">
          <Rating value={product.rating} count={product.reviewCount} />
        </div>
        <div className="mt-3 flex items-baseline gap-2">
          <span className="text-lg font-bold text-brand">
            ${product.price.toFixed(2)}
          </span>
          {product.oldPrice && (
            <span className="text-sm text-muted-foreground line-through">
              ${product.oldPrice.toFixed(2)}
            </span>
          )}
        </div>
        <div className="mt-4 flex gap-2">
          <Button
            size="sm"
            variant="outline"
            className="flex-1"
            onClick={handleAddToCart}
          >
            <ShoppingCart className="mr-1 h-4 w-4" />
            Add
          </Button>
          <Button
            size="sm"
            className="flex-1 bg-brand hover:bg-brand-600"
            onClick={handleBuyNow}
          >
            <Zap className="mr-1 h-4 w-4" />
            Buy Now
          </Button>
        </div>
      </div>
    </motion.div>
  );
}
