import { Star } from 'lucide-react';
import { cn } from '@/lib/utils';

interface RatingProps {
  value: number;
  count?: number;
  size?: 'sm' | 'md' | 'lg';
  showCount?: boolean;
  className?: string;
}

export function Rating({
  value,
  count,
  size = 'sm',
  showCount = true,
  className,
}: RatingProps) {
  const sizeMap = {
    sm: 'h-3.5 w-3.5',
    md: 'h-4 w-4',
    lg: 'h-5 w-5',
  };

  const hasReviews = value > 0 && count !== undefined && count > 0;

  if (!hasReviews) {
    return (
      <div className={cn('flex items-center gap-1.5', className)}>
        <div className="flex items-center">
          {[1, 2, 3, 4, 5].map((star) => (
            <Star
              key={star}
              className={cn(sizeMap[size], 'fill-muted text-muted-foreground/30')}
            />
          ))}
        </div>
        {showCount && (
          <span className="text-xs text-muted-foreground">No reviews yet</span>
        )}
      </div>
    );
  }

  return (
    <div className={cn('flex items-center gap-1.5', className)}>
      <div className="flex items-center">
        {[1, 2, 3, 4, 5].map((star) => {
          const filled = value >= star;
          const half = !filled && value >= star - 0.5;
          return (
            <Star
              key={star}
              className={cn(
                sizeMap[size],
                filled || half
                  ? 'fill-gold-400 text-gold-400'
                  : 'fill-muted text-muted-foreground/30'
              )}
            />
          );
        })}
      </div>
      <span className="text-sm font-medium text-foreground">
        {value.toFixed(1)}
      </span>
      {showCount && count !== undefined && (
        <span className="text-xs text-muted-foreground">({count})</span>
      )}
    </div>
  );
}
