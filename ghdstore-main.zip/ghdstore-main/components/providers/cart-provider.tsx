'use client';

import {
  createContext,
  useContext,
  useEffect,
  useMemo,
  useState,
} from 'react';

export interface CartItem {
  id: string;
  name: string;
  price: number;
  oldPrice?: number;
  image: string;
  category: string;
  quantity: number;
}

interface CartContextValue {
  items: CartItem[];
  wishlist: string[];
  addToCart: (item: Omit<CartItem, 'quantity'>, quantity?: number) => void;
  removeFromCart: (id: string) => void;
  updateQuantity: (id: string, quantity: number) => void;
  clearCart: () => void;
  toggleWishlist: (id: string) => void;
  isInWishlist: (id: string) => boolean;
  cartCount: number;
  subtotal: number;
  totalSavings: number;
}

const CartContext = createContext<CartContextValue | undefined>(undefined);

const CART_KEY = 'ghd-cart';
const WISH_KEY = 'ghd-wishlist';

export function CartProvider({ children }: { children: React.ReactNode }) {
  const [items, setItems] = useState<CartItem[]>([]);
  const [wishlist, setWishlist] = useState<string[]>([]);
  const [mounted, setMounted] = useState(false);

  useEffect(() => {
    setMounted(true);
    try {
      const cart = localStorage.getItem(CART_KEY);
      if (cart) setItems(JSON.parse(cart));
      const wish = localStorage.getItem(WISH_KEY);
      if (wish) setWishlist(JSON.parse(wish));
    } catch {
      // ignore parse errors
    }
  }, []);

  useEffect(() => {
    if (mounted) localStorage.setItem(CART_KEY, JSON.stringify(items));
  }, [items, mounted]);

  useEffect(() => {
    if (mounted) localStorage.setItem(WISH_KEY, JSON.stringify(wishlist));
  }, [wishlist, mounted]);

  const addToCart: CartContextValue['addToCart'] = (item, quantity = 1) => {
    setItems((prev) => {
      const existing = prev.find((i) => i.id === item.id);
      if (existing) {
        return prev.map((i) =>
          i.id === item.id ? { ...i, quantity: i.quantity + quantity } : i
        );
      }
      return [...prev, { ...item, quantity }];
    });
  };

  const removeFromCart = (id: string) => {
    setItems((prev) => prev.filter((i) => i.id !== id));
  };

  const updateQuantity = (id: string, quantity: number) => {
    if (quantity < 1) return;
    setItems((prev) =>
      prev.map((i) => (i.id === id ? { ...i, quantity } : i))
    );
  };

  const clearCart = () => setItems([]);

  const toggleWishlist = (id: string) => {
    setWishlist((prev) =>
      prev.includes(id) ? prev.filter((w) => w !== id) : [...prev, id]
    );
  };

  const isInWishlist = (id: string) => wishlist.includes(id);

  const cartCount = items.reduce((sum, i) => sum + i.quantity, 0);
  const subtotal = items.reduce((sum, i) => sum + i.price * i.quantity, 0);
  const totalSavings = items.reduce(
    (sum, i) => sum + (i.oldPrice ? (i.oldPrice - i.price) * i.quantity : 0),
    0
  );

  const value = useMemo(
    () => ({
      items,
      wishlist,
      addToCart,
      removeFromCart,
      updateQuantity,
      clearCart,
      toggleWishlist,
      isInWishlist,
      cartCount,
      subtotal,
      totalSavings,
    }),
    // eslint-disable-next-line react-hooks/exhaustive-deps
    [items, wishlist, cartCount, subtotal, totalSavings]
  );

  return <CartContext.Provider value={value}>{children}</CartContext.Provider>;
}

export function useCart() {
  const ctx = useContext(CartContext);
  if (!ctx) throw new Error('useCart must be used within CartProvider');
  return ctx;
}
