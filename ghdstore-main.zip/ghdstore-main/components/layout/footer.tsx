'use client';

import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Instagram,
  Mail,
  Phone,
  MapPin,
  Send,
} from 'lucide-react';
import { Input } from '@/components/ui/input';
import { Button } from '@/components/ui/button';
import { categories } from '@/lib/data/categories';

export function Footer() {
  const shopLinks = [
    { href: '/shop', label: 'All Products' },
    { href: '/shop?filter=flash', label: 'Flash Deals' },
    { href: '/shop?filter=new', label: 'New Arrivals' },
  ];

  const helpLinks = [
    { href: '/contact', label: 'Contact Us' },
    { href: '/about', label: 'About Us' },
    { href: '/shipping', label: 'Shipping Info' },
    { href: '/returns', label: 'Returns & Refunds' },
    { href: '/faq', label: 'FAQ' },
  ];

  return (
    <footer className="mt-20 border-t border-border bg-card">
      {/* Newsletter strip */}
      <div className="border-b border-border">
        <div className="container-ghd grid gap-8 py-12 md:grid-cols-2 md:items-center">
          <div>
            <h3 className="font-display text-2xl font-bold text-foreground">
              Join the GHD Community
            </h3>
            <p className="mt-2 text-sm text-muted-foreground">
              Subscribe for exclusive deals, new arrivals, and insider updates.
            </p>
          </div>
          <form className="flex gap-2">
            <Input
              type="email"
              placeholder="Enter your email"
              className="h-12 rounded-full"
            />
            <Button className="h-12 rounded-full bg-brand px-6 hover:bg-brand-600">
              <Send className="mr-2 h-4 w-4" />
              Subscribe
            </Button>
          </form>
        </div>
      </div>

      {/* Main footer */}
      <div className="container-ghd grid gap-10 py-14 md:grid-cols-2 lg:grid-cols-5">
        {/* Brand */}
        <div className="lg:col-span-2">
          <Link href="/" className="flex items-center gap-2">
            <div className="flex h-10 w-10 items-center justify-center rounded-xl bg-brand text-brand-foreground">
              <span className="font-display text-lg font-bold">G</span>
            </div>
            <span className="font-display text-lg font-bold text-foreground">
              GHD Stores
            </span>
          </Link>
          <p className="mt-4 max-w-sm text-sm leading-relaxed text-muted-foreground">
            Smart Gadgets • Home Decor • Everyday Essentials. Quality you can
            trust, delivered to your door.
          </p>
          <div className="mt-6 space-y-2">
            <div className="flex items-start gap-3 text-sm text-muted-foreground">
              <MapPin className="mt-0.5 h-4 w-4 flex-shrink-0 text-gold-500" />
              <span>Manimangalam House, Manjummel P.O., Eloor, Kerala, India</span>
            </div>
            <a
              href="tel:+919544894106"
              className="flex items-center gap-3 text-sm text-muted-foreground transition-colors hover:text-brand"
            >
              <Phone className="h-4 w-4 flex-shrink-0 text-gold-500" />
              +91 95448 94106
            </a>
            <div className="flex items-center gap-3 text-sm text-muted-foreground">
              <Mail className="h-4 w-4 flex-shrink-0 text-gold-500" />
              Email coming soon
            </div>
            <a
              href="https://www.instagram.com/g_h_d_store"
              target="_blank"
              rel="noopener noreferrer"
              className="flex items-center gap-3 text-sm text-muted-foreground transition-colors hover:text-brand"
            >
              <Instagram className="h-4 w-4 flex-shrink-0 text-gold-500" />
              @g_h_d_store
            </a>
          </div>
        </div>

        {/* Shop */}
        <div>
          <h4 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground">
            Shop
          </h4>
          <ul className="space-y-2.5">
            {shopLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-brand"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Categories */}
        <div>
          <h4 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground">
            Categories
          </h4>
          <ul className="space-y-2.5">
            {categories.map((cat) => (
              <li key={cat.id}>
                <Link
                  href={`/category/${cat.slug}`}
                  className="text-sm text-muted-foreground transition-colors hover:text-brand"
                >
                  {cat.name}
                </Link>
              </li>
            ))}
          </ul>
        </div>

        {/* Help */}
        <div>
          <h4 className="mb-4 text-sm font-bold uppercase tracking-wider text-foreground">
            Help
          </h4>
          <ul className="space-y-2.5">
            {helpLinks.map((link) => (
              <li key={link.href}>
                <Link
                  href={link.href}
                  className="text-sm text-muted-foreground transition-colors hover:text-brand"
                >
                  {link.label}
                </Link>
              </li>
            ))}
          </ul>
        </div>
      </div>

      {/* Bottom bar */}
      <div className="border-t border-border">
        <div className="container-ghd flex flex-col items-center justify-between gap-4 py-6 sm:flex-row">
          <p className="text-xs text-muted-foreground">
            © {new Date().getFullYear()} GHD Stores. All rights reserved.
          </p>
          <a
            href="https://www.instagram.com/g_h_d_store"
            target="_blank"
            rel="noopener noreferrer"
            aria-label="Instagram"
            className="flex h-9 w-9 items-center justify-center rounded-full border border-border text-muted-foreground transition-all hover:border-brand hover:bg-brand hover:text-brand-foreground"
          >
            <Instagram className="h-4 w-4" />
          </a>
        </div>
      </div>
    </footer>
  );
}
