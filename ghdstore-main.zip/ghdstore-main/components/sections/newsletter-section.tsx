'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, CheckCircle } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { useToast } from '@/hooks/use-toast';

export function NewsletterSection() {
  const [email, setEmail] = useState('');
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    if (!email) return;
    setSubmitted(true);
    toast({
      title: 'Subscribed successfully!',
      description: 'Welcome to the GHD Stores community.',
    });
    setEmail('');
    setTimeout(() => setSubmitted(false), 3000);
  };

  return (
    <section className="container-ghd py-16 lg:py-20">
      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="relative overflow-hidden rounded-3xl bg-gradient-to-br from-brand to-brand-600 px-6 py-14 text-center text-brand-foreground sm:px-12 lg:py-20"
      >
        {/* Decorative elements */}
        <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-gold-400/10 blur-2xl" />
        <div className="pointer-events-none absolute -right-10 -bottom-10 h-52 w-52 rounded-full bg-gold-400/10 blur-2xl" />

        <div className="relative mx-auto max-w-2xl">
          <div className="mb-5 flex justify-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-400/20 text-gold-400">
              <Mail className="h-7 w-7" />
            </div>
          </div>

          <h2 className="font-display text-3xl font-bold sm:text-4xl">
            Stay in the Loop
          </h2>
          <p className="mx-auto mt-4 max-w-md text-base text-brand-foreground/70">
            Subscribe to our newsletter for new arrivals, product updates,
            and the latest from GHD Stores.
          </p>

          <form
            onSubmit={handleSubmit}
            className="mx-auto mt-8 flex max-w-md flex-col gap-3 sm:flex-row"
          >
            <Input
              type="email"
              placeholder="Enter your email address"
              value={email}
              onChange={(e) => setEmail(e.target.value)}
              required
              className="h-12 flex-1 rounded-full border-brand-foreground/20 bg-brand-foreground/10 text-brand-foreground placeholder:text-brand-foreground/50"
            />
            <Button
              type="submit"
              size="lg"
              className="h-12 rounded-full bg-gold-400 px-8 text-black hover:bg-gold-500"
            >
              {submitted ? (
                <>
                  <CheckCircle className="mr-2 h-5 w-5" />
                  Subscribed!
                </>
              ) : (
                'Subscribe'
              )}
            </Button>
          </form>

          <p className="mt-4 text-xs text-brand-foreground/50">
            By subscribing, you agree to our Privacy Policy. Unsubscribe anytime.
          </p>
        </div>
      </motion.div>
    </section>
  );
}
