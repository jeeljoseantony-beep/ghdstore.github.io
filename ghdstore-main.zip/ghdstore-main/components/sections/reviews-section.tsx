'use client';

import { motion } from 'framer-motion';
import { MessageSquareHeart, Sparkles } from 'lucide-react';
import { SectionHeader } from '@/components/shared/section-header';

export function ReviewsSection() {
  return (
    <section className="container-ghd py-16 lg:py-20">
      <SectionHeader
        subtitle="Customer Reviews"
        title="What Our Customers Say"
      />

      <motion.div
        initial={{ opacity: 0, y: 20 }}
        whileInView={{ opacity: 1, y: 0 }}
        viewport={{ once: true }}
        transition={{ duration: 0.5 }}
        className="mx-auto max-w-2xl rounded-2xl border border-dashed border-border bg-muted/30 px-6 py-16 text-center"
      >
        <div className="mx-auto mb-5 flex h-16 w-16 items-center justify-center rounded-2xl bg-brand/10 text-brand">
          <MessageSquareHeart className="h-8 w-8" />
        </div>
        <h3 className="font-display text-xl font-bold text-foreground">
          Reviews Coming Soon
        </h3>
        <p className="mx-auto mt-3 max-w-md text-sm leading-relaxed text-muted-foreground">
          Our customer reviews will appear here as orders start coming in.
          We are a newly launched store and can&apos;t wait to hear what you think!
        </p>
        <div className="mt-5 inline-flex items-center gap-1.5 rounded-full bg-gold-400/10 px-4 py-1.5 text-sm font-medium text-gold-600 dark:text-gold-300">
          <Sparkles className="h-4 w-4" />
          Be the first to shop and review
        </div>
      </motion.div>
    </section>
  );
}
