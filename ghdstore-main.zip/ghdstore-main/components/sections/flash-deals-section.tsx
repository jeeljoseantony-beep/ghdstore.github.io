'use client';

import { motion } from 'framer-motion';
import { Zap } from 'lucide-react';
import { SectionHeader } from '@/components/shared/section-header';
import { ProductRow } from '@/components/shared/product-row';
import { CountdownTimer } from '@/components/shared/countdown-timer';
import { products } from '@/lib/data/products';

export function FlashDealsSection() {
  const flashProducts = products.filter((p) => p.isFlashDeal);

  return (
    <section className="bg-gradient-to-b from-brand-50/50 to-background py-16 dark:from-brand-900/10 dark:to-background lg:py-20">
      <div className="container-ghd">
        <div className="mb-8 flex flex-col items-start justify-between gap-4 sm:flex-row sm:items-end">
          <motion.div
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.5 }}
          >
            <div className="mb-2 flex items-center gap-2">
              <span className="flex items-center gap-1.5 rounded-full bg-gold-400/20 px-3 py-1 text-sm font-semibold text-gold-600 dark:text-gold-300">
                <Zap className="h-4 w-4 fill-current" />
                Limited Time
              </span>
            </div>
            <h2 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
              Flash Deals
            </h2>
          </motion.div>
          <CountdownTimer hours={12} />
        </div>

        <ProductRow products={flashProducts} />
      </div>
    </section>
  );
}
