'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { ArrowRight } from 'lucide-react';
import { SectionHeader } from '@/components/shared/section-header';
import { categories } from '@/lib/data/categories';

export function CategorySection() {
  return (
    <section className="container-ghd py-16 lg:py-20">
      <SectionHeader
        subtitle="Browse Collection"
        title="Shop by Category"
        href="/categories"
      />

      <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-6">
        {categories.map((cat, index) => (
          <motion.div
            key={cat.id}
            initial={{ opacity: 0, y: 20 }}
            whileInView={{ opacity: 1, y: 0 }}
            viewport={{ once: true }}
            transition={{ duration: 0.4, delay: index * 0.05 }}
          >
            <Link
              href={`/category/${cat.slug}`}
              className="group relative flex flex-col items-center overflow-hidden rounded-2xl border border-border bg-card p-4 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
            >
              <div className="relative mb-3 h-20 w-20 overflow-hidden rounded-full bg-muted">
                <Image
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="80px"
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
              </div>
              <h3 className="text-sm font-semibold text-foreground transition-colors group-hover:text-brand">
                {cat.name}
              </h3>
              <p className="mt-0.5 text-xs text-muted-foreground">
                {cat.productCount} items
              </p>
              <ArrowRight className="mt-2 h-4 w-4 text-gold-500 opacity-0 transition-all duration-300 group-hover:opacity-100" />
            </Link>
          </motion.div>
        ))}
      </div>
    </section>
  );
}
