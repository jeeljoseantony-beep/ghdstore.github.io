'use client';

import { motion } from 'framer-motion';
import { Package, ShieldCheck, Headphones, RefreshCw, Award, Leaf } from 'lucide-react';

const features = [
  {
    icon: Package,
    title: 'Carefully Packaged',
    description: 'Every order is packed with care to arrive in pristine condition.',
  },
  {
    icon: ShieldCheck,
    title: 'Secure Payment',
    description: 'Bank-grade encryption protects every transaction you make.',
  },
  {
    icon: RefreshCw,
    title: 'Easy 30-Day Returns',
    description: 'Not satisfied? Return any item within 30 days for a full refund.',
  },
  {
    icon: Headphones,
    title: '24/7 Support',
    description: 'Our dedicated team is always here to help with any questions.',
  },
  {
    icon: Award,
    title: 'Premium Quality',
    description: 'Every product is hand-selected and quality-tested by our team.',
  },
  {
    icon: Leaf,
    title: 'Eco-Friendly',
    description: 'Sustainable packaging and responsibly sourced products.',
  },
];

export function WhyChooseSection() {
  return (
    <section className="relative overflow-hidden bg-brand py-20 text-brand-foreground lg:py-24">
      {/* Decorative pattern */}
      <div className="pointer-events-none absolute inset-0 opacity-5">
        <div className="absolute -left-10 top-10 h-40 w-40 rounded-full border border-gold-400" />
        <div className="absolute right-10 top-1/3 h-60 w-60 rounded-full border border-gold-400" />
        <div className="absolute bottom-10 left-1/3 h-32 w-32 rounded-full border border-gold-400" />
      </div>

      <div className="container-ghd relative">
        <motion.div
          initial={{ opacity: 0, y: 20 }}
          whileInView={{ opacity: 1, y: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="mx-auto mb-12 max-w-2xl text-center"
        >
          <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-gold-400">
            Why GHD Stores
          </p>
          <h2 className="font-display text-3xl font-bold sm:text-4xl">
            The GHD Stores Difference
          </h2>
          <p className="mt-4 text-base text-brand-foreground/70">
            We are committed to delivering an exceptional shopping experience
            with premium products and outstanding service.
          </p>
        </motion.div>

        <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
          {features.map((feature, index) => (
            <motion.div
              key={feature.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
              className="group rounded-2xl border border-brand-foreground/10 bg-brand-foreground/5 p-6 transition-all duration-300 hover:border-gold-400/30 hover:bg-brand-foreground/10"
            >
              <div className="mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-gold-400/20 text-gold-400 transition-transform duration-300 group-hover:scale-110">
                <feature.icon className="h-6 w-6" />
              </div>
              <h3 className="mb-2 text-lg font-semibold">{feature.title}</h3>
              <p className="text-sm leading-relaxed text-brand-foreground/70">
                {feature.description}
              </p>
            </motion.div>
          ))}
        </div>
      </div>
    </section>
  );
}
