'use client';

import { motion } from 'framer-motion';
import { ProductCard } from '@/components/shared/product-card';
import { SectionHeader } from '@/components/shared/section-header';
import type { Product } from '@/lib/types';

interface ProductGridSectionProps {
  title: string;
  subtitle: string;
  href: string;
  products: Product[];
  background?: 'default' | 'muted';
}

export function ProductGridSection({
  title,
  subtitle,
  href,
  products,
  background = 'default',
}: ProductGridSectionProps) {
  return (
    <section
      className={
        background === 'muted'
          ? 'bg-muted/30 py-16 lg:py-20'
          : 'py-16 lg:py-20'
      }
    >
      <div className="container-ghd">
        <SectionHeader subtitle={subtitle} title={title} href={href} />
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {products.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      </div>
    </section>
  );
}
