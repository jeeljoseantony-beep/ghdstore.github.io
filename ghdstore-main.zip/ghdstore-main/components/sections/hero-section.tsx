'use client';

import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { ArrowRight, Sparkles, ShieldCheck } from 'lucide-react';
import { Button } from '@/components/ui/button';

export function HeroSection() {
  return (
    <section className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-background to-brand-50/30 dark:from-brand-900/30 dark:via-background dark:to-brand-900/20">
      {/* Decorative blobs */}
      <div className="pointer-events-none absolute -left-20 top-10 h-72 w-72 rounded-full bg-gold-400/10 blur-3xl" />
      <div className="pointer-events-none absolute -right-20 bottom-0 h-96 w-96 rounded-full bg-brand/10 blur-3xl" />

      <div className="container-ghd relative grid items-center gap-12 py-16 lg:grid-cols-2 lg:py-24">
        {/* Left content */}
        <motion.div
          initial={{ opacity: 0, x: -30 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.6 }}
          className="flex flex-col items-start"
        >
          <div className="mb-5 inline-flex items-center gap-2 rounded-full border border-gold-400/30 bg-gold-400/10 px-4 py-1.5 text-sm font-medium text-gold-600 dark:text-gold-300">
            <Sparkles className="h-4 w-4" />
            Premium Quality, Smart Living
          </div>

          <h1 className="font-display text-4xl font-bold leading-tight text-foreground sm:text-5xl lg:text-6xl">
            Elevate Your{' '}
            <span className="gold-text">Everyday</span>
            <br />
            with Smart Essentials
          </h1>

          <p className="mt-5 max-w-md text-base leading-relaxed text-muted-foreground sm:text-lg">
            Discover curated smart gadgets, elegant home decor, and everyday
            essentials designed to make life smarter, simpler, and more
            beautiful.
          </p>

          <div className="mt-8 flex flex-col gap-3 sm:flex-row">
            <Link href="/shop">
              <Button size="lg" className="h-12 rounded-full bg-brand px-8 text-base hover:bg-brand-600">
                Shop Now
                <ArrowRight className="ml-2 h-5 w-5" />
              </Button>
            </Link>
            <Link href="/categories">
              <Button size="lg" variant="outline" className="h-12 rounded-full px-8 text-base">
                Browse Categories
              </Button>
            </Link>
          </div>

          {/* Trust signals */}
          <div className="mt-10 flex flex-wrap gap-x-6 gap-y-2 text-sm text-muted-foreground">
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-brand" />
              Secure checkout
            </span>
            <span className="flex items-center gap-1.5">
              <Sparkles className="h-4 w-4 text-gold-500" />
              Curated quality
            </span>
            <span className="flex items-center gap-1.5">
              <ShieldCheck className="h-4 w-4 text-brand" />
              Trusted new brand
            </span>
          </div>
        </motion.div>

        {/* Right visual */}
        <motion.div
          initial={{ opacity: 0, scale: 0.95 }}
          animate={{ opacity: 1, scale: 1 }}
          transition={{ duration: 0.6, delay: 0.2 }}
          className="relative hidden lg:block"
        >
          <div className="relative aspect-square">
            {/* Main image */}
            <div className="absolute inset-0 overflow-hidden rounded-3xl border border-border shadow-2xl">
              <Image
                src="https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=900"
                alt="Premium smart gadgets and home decor"
                fill
                priority
                className="object-cover"
              />
            </div>

            {/* Floating card 1 */}
            <motion.div
              animate={{ y: [0, -12, 0] }}
              transition={{ duration: 4, repeat: Infinity, ease: 'easeInOut' }}
              className="absolute -left-8 top-12 flex items-center gap-3 rounded-2xl border border-border bg-card/95 p-3 shadow-xl backdrop-blur"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-brand/10">
                <Sparkles className="h-5 w-5 text-brand" />
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">Smart Home</p>
                <p className="text-[10px] text-muted-foreground">Connected Living</p>
              </div>
            </motion.div>

            {/* Floating card 2 */}
            <motion.div
              animate={{ y: [0, 12, 0] }}
              transition={{ duration: 5, repeat: Infinity, ease: 'easeInOut', delay: 1 }}
              className="absolute -right-6 bottom-16 flex items-center gap-3 rounded-2xl border border-border bg-card/95 p-3 shadow-xl backdrop-blur"
            >
              <div className="flex h-10 w-10 items-center justify-center rounded-full bg-gold-400/20">
                <ShieldCheck className="h-5 w-5 text-gold-500" />
              </div>
              <div>
                <p className="text-xs font-semibold text-foreground">New Arrivals</p>
                <p className="text-[10px] text-muted-foreground">Freshly Curated</p>
              </div>
            </motion.div>

            {/* Floating badge */}
            <motion.div
              animate={{ y: [0, -8, 0] }}
              transition={{ duration: 3.5, repeat: Infinity, ease: 'easeInOut', delay: 0.5 }}
              className="absolute -bottom-4 left-1/2 -translate-x-1/2 rounded-full bg-gold-400 px-5 py-2 text-sm font-bold text-black shadow-xl"
            >
              Up to 40% OFF
            </motion.div>
          </div>
        </motion.div>
      </div>
    </section>
  );
}
