import Link from 'next/link';
import Image from 'next/image';
import { Award, Target, Heart, Leaf, Users, TrendingUp } from 'lucide-react';
import { Button } from '@/components/ui/button';

export const metadata = {
  title: 'About Us',
  description: 'Learn about GHD Stores - our mission, values, and commitment to delivering premium smart gadgets and home essentials.',
};

const values = [
  {
    icon: Award,
    title: 'Quality First',
    description: 'Every product is rigorously tested and hand-selected to meet our premium standards.',
  },
  {
    icon: Heart,
    title: 'Customer Obsessed',
    description: 'Your satisfaction drives everything we do. We are here to serve you, always.',
  },
  {
    icon: Leaf,
    title: 'Sustainability',
    description: 'We prioritize eco-friendly packaging and responsibly sourced products.',
  },
  {
    icon: TrendingUp,
    title: 'Innovation',
    description: 'We stay ahead of trends to bring you the latest in smart technology.',
  },
];

export default function AboutPage() {
  return (
    <div>
      {/* Hero */}
      <section className="relative overflow-hidden bg-gradient-to-br from-brand-50 via-background to-brand-50/30 py-16 dark:from-brand-900/20 dark:via-background dark:to-brand-900/10 lg:py-24">
        <div className="container-ghd grid items-center gap-12 lg:grid-cols-2">
          <div>
            <p className="mb-3 text-sm font-semibold uppercase tracking-widest text-gold-500">
              Our Story
            </p>
            <h1 className="font-display text-4xl font-bold text-foreground sm:text-5xl">
              Smart Living,{' '}
              <span className="gold-text">Beautifully Designed</span>
            </h1>
            <p className="mt-5 text-base leading-relaxed text-muted-foreground sm:text-lg">
              GHD Stores was founded with a simple belief: everyday products
              should be smart, beautiful, and accessible. We curate premium
              gadgets and home essentials that elevate your daily life without
              compromising on quality or design.
            </p>
            <div className="mt-8 flex gap-3">
              <Link href="/shop">
                <Button size="lg" className="rounded-full bg-brand px-8 hover:bg-brand-600">
                  Explore Products
                </Button>
              </Link>
              <Link href="/contact">
                <Button size="lg" variant="outline" className="rounded-full px-8">
                  Get in Touch
                </Button>
              </Link>
            </div>
          </div>
          <div className="relative aspect-square hidden lg:block">
            <div className="absolute inset-0 overflow-hidden rounded-3xl border border-border shadow-2xl">
              <Image
                src="https://images.pexels.com/photos/3184339/pexels-photo-3184339.jpeg?auto=compress&cs=tinysrgb&w=900"
                alt="GHD Stores team"
                fill
                className="object-cover"
                sizes="50vw"
              />
            </div>
          </div>
        </div>
      </section>

      {/* Mission */}
      <section className="container-ghd py-16 lg:py-20">
        <div className="mx-auto max-w-3xl text-center">
          <div className="mb-5 flex justify-center">
            <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-brand/10 text-brand">
              <Target className="h-7 w-7" />
            </div>
          </div>
          <h2 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
            Our Mission
          </h2>
          <p className="mt-4 text-base leading-relaxed text-muted-foreground sm:text-lg">
            To make premium smart living accessible to everyone. We believe
            technology and design should work together seamlessly to enhance
            your everyday experiences — from the way you cool your space to how
            you light your home.
          </p>
        </div>
      </section>

      {/* Values */}
      <section className="bg-muted/30 py-16 lg:py-20">
        <div className="container-ghd">
          <div className="mb-12 text-center">
            <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-gold-500">
              What We Stand For
            </p>
            <h2 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
              Our Core Values
            </h2>
          </div>
          <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-4">
            {values.map((value) => (
              <div
                key={value.title}
                className="rounded-2xl border border-border bg-card p-6 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg"
              >
                <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand/10 text-brand">
                  <value.icon className="h-6 w-6" />
                </div>
                <h3 className="mb-2 text-lg font-semibold text-foreground">
                  {value.title}
                </h3>
                <p className="text-sm leading-relaxed text-muted-foreground">
                  {value.description}
                </p>
              </div>
            ))}
          </div>
        </div>
      </section>

      {/* CTA */}
      <section className="container-ghd py-16 lg:py-20">
        <div className="relative overflow-hidden rounded-3xl bg-brand px-6 py-14 text-center text-brand-foreground lg:py-20">
          <div className="pointer-events-none absolute -left-10 -top-10 h-40 w-40 rounded-full bg-gold-400/10 blur-2xl" />
          <div className="pointer-events-none absolute -right-10 -bottom-10 h-52 w-52 rounded-full bg-gold-400/10 blur-2xl" />
          <div className="relative mx-auto max-w-2xl">
            <div className="mb-5 flex justify-center">
              <div className="flex h-14 w-14 items-center justify-center rounded-2xl bg-gold-400/20 text-gold-400">
                <Users className="h-7 w-7" />
              </div>
            </div>
            <h2 className="font-display text-3xl font-bold sm:text-4xl">
              Join the GHD Community
            </h2>
            <p className="mx-auto mt-4 max-w-md text-brand-foreground/70">
              Discover premium products that make life smarter, simpler, and
              more beautiful. Your journey to smart living starts here.
            </p>
            <Link href="/shop" className="mt-8 inline-block">
              <Button size="lg" className="rounded-full bg-gold-400 px-8 text-black hover:bg-gold-500">
                Start Shopping
              </Button>
            </Link>
          </div>
        </div>
      </section>
    </div>
  );
}
