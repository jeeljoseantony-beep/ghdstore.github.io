import Link from 'next/link';
import { Button } from '@/components/ui/button';
import { Home, ArrowLeft } from 'lucide-react';

export default function NotFound() {
  return (
    <div className="container-ghd flex flex-col items-center justify-center py-20 text-center">
      <p className="font-display text-8xl font-bold text-brand/20">404</p>
      <h1 className="mt-4 font-display text-3xl font-bold text-foreground">
        Page Not Found
      </h1>
      <p className="mt-2 max-w-sm text-muted-foreground">
        The page you are looking for doesn&apos;t exist or has been moved.
      </p>
      <div className="mt-6 flex gap-3">
        <Link href="/">
          <Button className="rounded-full bg-brand px-8 hover:bg-brand-600">
            <Home className="mr-2 h-5 w-5" />
            Go Home
          </Button>
        </Link>
        <Link href="/shop">
          <Button variant="outline" className="rounded-full px-8">
            <ArrowLeft className="mr-2 h-5 w-5" />
            Browse Shop
          </Button>
        </Link>
      </div>
    </div>
  );
}
