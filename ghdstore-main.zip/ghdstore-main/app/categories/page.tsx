import Link from 'next/link';
import Image from 'next/image';
import { ArrowRight } from 'lucide-react';
import { categories } from '@/lib/data/categories';
import { products } from '@/lib/data/products';

export const metadata = {
  title: 'Categories',
  description: 'Browse all product categories at GHD Stores - Mini Fans, Air Humidifiers, Smart Lights, Home Decor, USB Gadgets, and Mobile Accessories.',
};

export default function CategoriesPage() {
  return (
    <div className="container-ghd py-8 lg:py-12">
      <div className="mb-10 text-center">
        <h1 className="font-display text-4xl font-bold text-foreground sm:text-5xl">
          Shop by Category
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
          Explore our curated collections of premium smart gadgets and home essentials
        </p>
      </div>

      <div className="grid gap-6 sm:grid-cols-2 lg:grid-cols-3">
        {categories.map((cat) => {
          const catProducts = products.filter((p) => p.categorySlug === cat.slug);
          const startingPrice = catProducts.length > 0
            ? Math.min(...catProducts.map((p) => p.price))
            : 0;

          return (
            <Link
              key={cat.id}
              href={`/category/${cat.slug}`}
              className="group relative overflow-hidden rounded-2xl border border-border bg-card shadow-sm transition-all duration-300 hover:-translate-y-1 hover:shadow-xl"
            >
              <div className="relative aspect-[4/3] overflow-hidden">
                <Image
                  src={cat.image}
                  alt={cat.name}
                  fill
                  sizes="(max-width: 768px) 100vw, (max-width: 1200px) 50vw, 33vw"
                  className="object-cover transition-transform duration-500 group-hover:scale-110"
                />
                <div className="absolute inset-0 bg-gradient-to-t from-black/70 via-black/20 to-transparent" />
                <div className="absolute bottom-0 left-0 right-0 p-5 text-white">
                  <h2 className="font-display text-2xl font-bold">{cat.name}</h2>
                  <p className="mt-1 text-sm text-white/80">{cat.description}</p>
                </div>
              </div>
              <div className="flex items-center justify-between p-4">
                <div>
                  <p className="text-xs text-muted-foreground">
                    {cat.productCount} products
                  </p>
                  <p className="text-sm font-semibold text-foreground">
                    From ${startingPrice.toFixed(2)}
                  </p>
                </div>
                <span className="flex items-center gap-1 text-sm font-semibold text-brand transition-colors group-hover:text-gold-500">
                  Shop now
                  <ArrowRight className="h-4 w-4 transition-transform group-hover:translate-x-1" />
                </span>
              </div>
            </Link>
          );
        })}
      </div>
    </div>
  );
}
