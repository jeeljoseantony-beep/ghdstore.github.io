'use client';

import { useMemo, useState, useEffect } from 'react';
import { useSearchParams } from 'next/navigation';
import { motion } from 'framer-motion';
import { SlidersHorizontal, X, Search as SearchIcon } from 'lucide-react';
import { ProductCard } from '@/components/shared/product-card';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Checkbox } from '@/components/ui/checkbox';
import { Label } from '@/components/ui/label';
import {
  Select,
  SelectContent,
  SelectItem,
  SelectTrigger,
  SelectValue,
} from '@/components/ui/select';
import { Sheet, SheetContent, SheetHeader, SheetTitle, SheetTrigger } from '@/components/ui/sheet';
import { products } from '@/lib/data/products';
import { categories } from '@/lib/data/categories';
import { useCart } from '@/components/providers/cart-provider';
import { cn } from '@/lib/utils';

export default function ShopPage() {
  const searchParams = useSearchParams();
  const queryParam = searchParams.get('q') || '';
  const filterParam = searchParams.get('filter') || '';
  const { wishlist } = useCart();

  const [search, setSearch] = useState(queryParam);
  const [selectedCategories, setSelectedCategories] = useState<string[]>([]);
  const [priceRange, setPriceRange] = useState<[number, number]>([0, 100]);
  const [minRating, setMinRating] = useState(0);
  const [sortBy, setSortBy] = useState('featured');
  const [showWishlistOnly, setShowWishlistOnly] = useState(false);
  const [mobileFiltersOpen, setMobileFiltersOpen] = useState(false);

  useEffect(() => {
    setSearch(queryParam);
  }, [queryParam]);

  useEffect(() => {
    if (filterParam === 'wishlist') setShowWishlistOnly(true);
  }, [filterParam]);

  const toggleCategory = (slug: string) => {
    setSelectedCategories((prev) =>
      prev.includes(slug)
        ? prev.filter((c) => c !== slug)
        : [...prev, slug]
    );
  };

  const filtered = useMemo(() => {
    let result = [...products];

    // Filter by special filters
    if (filterParam === 'flash') result = result.filter((p) => p.isFlashDeal);
    if (filterParam === 'new') result = result.filter((p) => p.isNewArrival);

    // Wishlist filter
    if (showWishlistOnly) {
      result = result.filter((p) => wishlist.includes(p.id));
    }

    // Search
    if (search) {
      const q = search.toLowerCase();
      result = result.filter(
        (p) =>
          p.name.toLowerCase().includes(q) ||
          p.category.toLowerCase().includes(q) ||
          p.tags.some((t) => t.includes(q))
      );
    }

    // Category filter
    if (selectedCategories.length > 0) {
      result = result.filter((p) => selectedCategories.includes(p.categorySlug));
    }

    // Price filter
    result = result.filter(
      (p) => p.price >= priceRange[0] && p.price <= priceRange[1]
    );

    // Rating filter
    if (minRating > 0) {
      result = result.filter((p) => p.rating >= minRating);
    }

    // Sort
    switch (sortBy) {
      case 'price-low':
        result.sort((a, b) => a.price - b.price);
        break;
      case 'price-high':
        result.sort((a, b) => b.price - a.price);
        break;
      case 'rating':
        result.sort((a, b) => b.rating - a.rating);
        break;
      case 'newest':
        result.sort((a, b) => (b.isNewArrival ? 1 : 0) - (a.isNewArrival ? 1 : 0));
        break;
      default:
        break;
    }

    return result;
  }, [search, selectedCategories, priceRange, minRating, sortBy, showWishlistOnly, wishlist, filterParam]);

  const clearFilters = () => {
    setSelectedCategories([]);
    setPriceRange([0, 100]);
    setMinRating(0);
    setShowWishlistOnly(false);
    setSearch('');
  };

  const activeFilterCount =
    selectedCategories.length +
    (minRating > 0 ? 1 : 0) +
    (showWishlistOnly ? 1 : 0) +
    (search ? 1 : 0);

  const FilterContent = () => (
    <div className="space-y-6">
      {/* Search */}
      <div>
        <Label className="mb-2 block text-sm font-semibold">Search</Label>
        <div className="relative">
          <SearchIcon className="absolute left-3 top-1/2 h-4 w-4 -translate-y-1/2 text-muted-foreground" />
          <Input
            placeholder="Search products..."
            value={search}
            onChange={(e) => setSearch(e.target.value)}
            className="pl-10"
          />
        </div>
      </div>

      {/* Wishlist filter */}
      <div>
        <Label className="mb-3 block text-sm font-semibold">Special</Label>
        <div className="flex items-center space-x-2">
          <Checkbox
            id="wishlist"
            checked={showWishlistOnly}
            onCheckedChange={(c) => setShowWishlistOnly(c === true)}
          />
          <Label htmlFor="wishlist" className="text-sm cursor-pointer">
            Show wishlist only ({wishlist.length})
          </Label>
        </div>
      </div>

      {/* Categories */}
      <div>
        <Label className="mb-3 block text-sm font-semibold">Categories</Label>
        <div className="space-y-2.5">
          {categories.map((cat) => (
            <div key={cat.id} className="flex items-center space-x-2">
              <Checkbox
                id={cat.slug}
                checked={selectedCategories.includes(cat.slug)}
                onCheckedChange={() => toggleCategory(cat.slug)}
              />
              <Label htmlFor={cat.slug} className="cursor-pointer text-sm">
                {cat.name} ({cat.productCount})
              </Label>
            </div>
          ))}
        </div>
      </div>

      {/* Price range */}
      <div>
        <Label className="mb-3 block text-sm font-semibold">
          Price Range: ${priceRange[0]} - ${priceRange[1]}
        </Label>
        <div className="space-y-3">
          <div>
            <label className="mb-1 block text-xs text-muted-foreground">Min: ${priceRange[0]}</label>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={priceRange[0]}
              onChange={(e) =>
                setPriceRange([Number(e.target.value), priceRange[1]])
              }
              className="w-full accent-brand"
            />
          </div>
          <div>
            <label className="mb-1 block text-xs text-muted-foreground">Max: ${priceRange[1]}</label>
            <input
              type="range"
              min={0}
              max={100}
              step={5}
              value={priceRange[1]}
              onChange={(e) =>
                setPriceRange([priceRange[0], Number(e.target.value)])
              }
              className="w-full accent-brand"
            />
          </div>
        </div>
      </div>

      {/* Rating */}
      <div>
        <Label className="mb-3 block text-sm font-semibold">Minimum Rating</Label>
        <div className="space-y-2">
          {[0, 3, 4, 4.5].map((r) => (
            <div key={r} className="flex items-center space-x-2">
              <Checkbox
                id={`rating-${r}`}
                checked={minRating === r}
                onCheckedChange={() => setMinRating(r)}
              />
              <Label htmlFor={`rating-${r}`} className="cursor-pointer text-sm">
                {r === 0 ? 'All ratings' : `${r}+ stars`}
              </Label>
            </div>
          ))}
        </div>
      </div>

      {activeFilterCount > 0 && (
        <Button variant="outline" className="w-full" onClick={clearFilters}>
          Clear all filters ({activeFilterCount})
        </Button>
      )}
    </div>
  );

  return (
    <div className="container-ghd py-8 lg:py-12">
      {/* Page header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
          Shop All Products
        </h1>
        <p className="mt-2 text-muted-foreground">
          Discover our full collection of premium smart gadgets and home essentials
        </p>
      </div>

      <div className="flex gap-8">
        {/* Desktop sidebar */}
        <aside className="hidden w-64 flex-shrink-0 lg:block">
          <div className="sticky top-28 rounded-2xl border border-border bg-card p-5">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-sm font-bold uppercase tracking-wider">Filters</h2>
              {activeFilterCount > 0 && (
                <button
                  onClick={clearFilters}
                  className="text-xs text-brand hover:underline"
                >
                  Clear all
                </button>
              )}
            </div>
            <FilterContent />
          </div>
        </aside>

        {/* Main content */}
        <div className="flex-1">
          {/* Toolbar */}
          <div className="mb-6 flex items-center justify-between gap-4">
            <div className="flex items-center gap-3">
              {/* Mobile filter trigger */}
              <Sheet open={mobileFiltersOpen} onOpenChange={setMobileFiltersOpen}>
                <SheetTrigger asChild>
                  <Button variant="outline" className="lg:hidden">
                    <SlidersHorizontal className="mr-2 h-4 w-4" />
                    Filters
                    {activeFilterCount > 0 && (
                      <span className="ml-1.5 rounded-full bg-brand px-1.5 py-0.5 text-xs text-brand-foreground">
                        {activeFilterCount}
                      </span>
                    )}
                  </Button>
                </SheetTrigger>
                <SheetContent side="left" className="w-[320px] overflow-y-auto">
                  <SheetHeader>
                    <SheetTitle>Filters</SheetTitle>
                  </SheetHeader>
                  <div className="mt-6 px-1">
                    <FilterContent />
                  </div>
                </SheetContent>
              </Sheet>

              <p className="text-sm text-muted-foreground">
                <span className="font-semibold text-foreground">{filtered.length}</span> products
              </p>
            </div>

            <Select value={sortBy} onValueChange={setSortBy}>
              <SelectTrigger className="w-[180px]">
                <SelectValue placeholder="Sort by" />
              </SelectTrigger>
              <SelectContent>
                <SelectItem value="featured">Featured</SelectItem>
                <SelectItem value="price-low">Price: Low to High</SelectItem>
                <SelectItem value="price-high">Price: High to Low</SelectItem>
                <SelectItem value="rating">Top Rated</SelectItem>
                <SelectItem value="newest">Newest</SelectItem>
              </SelectContent>
            </Select>
          </div>

          {/* Active filter chips */}
          {activeFilterCount > 0 && (
            <div className="mb-4 flex flex-wrap gap-2">
              {search && (
                <span className="flex items-center gap-1 rounded-full bg-muted px-3 py-1 text-xs">
                  &ldquo;{search}&rdquo;
                  <button onClick={() => setSearch('')}><X className="h-3 w-3" /></button>
                </span>
              )}
              {selectedCategories.map((slug) => {
                const cat = categories.find((c) => c.slug === slug);
                return (
                  <span key={slug} className="flex items-center gap-1 rounded-full bg-muted px-3 py-1 text-xs">
                    {cat?.name}
                    <button onClick={() => toggleCategory(slug)}><X className="h-3 w-3" /></button>
                  </span>
                );
              })}
              {showWishlistOnly && (
                <span className="flex items-center gap-1 rounded-full bg-muted px-3 py-1 text-xs">
                  Wishlist
                  <button onClick={() => setShowWishlistOnly(false)}><X className="h-3 w-3" /></button>
                </span>
              )}
            </div>
          )}

          {/* Products grid */}
          {filtered.length > 0 ? (
            <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 xl:grid-cols-4">
              {filtered.map((product, index) => (
                <ProductCard key={product.id} product={product} index={index} />
              ))}
            </div>
          ) : (
            <div className="flex flex-col items-center justify-center rounded-2xl border border-dashed border-border py-20 text-center">
              <p className="text-lg font-semibold text-foreground">No products found</p>
              <p className="mt-1 text-sm text-muted-foreground">
                Try adjusting your filters or search terms
              </p>
              <Button onClick={clearFilters} className="mt-4">
                Clear all filters
              </Button>
            </div>
          )}
        </div>
      </div>
    </div>
  );
}
