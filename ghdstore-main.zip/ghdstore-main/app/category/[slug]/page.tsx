'use client';

import { useParams } from 'next/navigation';
import Link from 'next/link';
import { ChevronRight } from 'lucide-react';
import { ProductCard } from '@/components/shared/product-card';
import { categories } from '@/lib/data/categories';
import { products } from '@/lib/data/products';

export default function CategoryPage() {
  const params = useParams();
  const slug = params.slug as string;
  const category = categories.find((c) => c.slug === slug);
  const categoryProducts = products.filter((p) => p.categorySlug === slug);

  if (!category) {
    return (
      <div className="container-ghd py-20 text-center">
        <h1 className="text-2xl font-bold">Category not found</h1>
        <Link href="/categories" className="mt-4 inline-block text-brand hover:underline">
          Browse all categories
        </Link>
      </div>
    );
  }

  return (
    <div className="container-ghd py-8 lg:py-12">
      {/* Breadcrumb */}
      <nav className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground">
        <Link href="/" className="hover:text-brand">Home</Link>
        <ChevronRight className="h-4 w-4" />
        <Link href="/categories" className="hover:text-brand">Categories</Link>
        <ChevronRight className="h-4 w-4" />
        <span className="text-foreground">{category.name}</span>
      </nav>

      {/* Header */}
      <div className="mb-8">
        <h1 className="font-display text-3xl font-bold text-foreground sm:text-4xl">
          {category.name}
        </h1>
        <p className="mt-2 text-muted-foreground">{category.description}</p>
        <p className="mt-1 text-sm text-muted-foreground">
          {categoryProducts.length} products available
        </p>
      </div>

      {/* Products */}
      {categoryProducts.length > 0 ? (
        <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
          {categoryProducts.map((product, index) => (
            <ProductCard key={product.id} product={product} index={index} />
          ))}
        </div>
      ) : (
        <div className="rounded-2xl border border-dashed border-border py-20 text-center">
          <p className="text-lg font-semibold">No products in this category yet</p>
          <Link href="/shop" className="mt-4 inline-block text-brand hover:underline">
            Browse all products
          </Link>
        </div>
      )}
    </div>
  );
}
