'use client';

import { useState } from 'react';
import { notFound, useParams } from 'next/navigation';
import Image from 'next/image';
import Link from 'next/link';
import { motion } from 'framer-motion';
import {
  Heart,
  ShoppingCart,
  Zap,
  Minus,
  Plus,
  Package,
  ShieldCheck,
  RefreshCw,
  Check,
  ChevronRight,
} from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Rating } from '@/components/shared/rating';
import { ProductCard } from '@/components/shared/product-card';
import { SectionHeader } from '@/components/shared/section-header';
import { useCart } from '@/components/providers/cart-provider';
import { useToast } from '@/hooks/use-toast';
import { getProductBySlug, getRelatedProducts } from '@/lib/data/products';
import { cn } from '@/lib/utils';

export default function ProductDetailsPage() {
  const params = useParams();
  const slug = params.slug as string;
  const product = getProductBySlug(slug);

  if (!product) notFound();

  const [selectedImage, setSelectedImage] = useState(0);
  const [quantity, setQuantity] = useState(1);
  const { addToCart, toggleWishlist, isInWishlist } = useCart();
  const { toast } = useToast();
  const wished = isInWishlist(product.id);
  const related = getRelatedProducts(product, 4);

  const discount = product.oldPrice
    ? Math.round(((product.oldPrice - product.price) / product.oldPrice) * 100)
    : 0;

  const handleAddToCart = () => {
    addToCart(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        oldPrice: product.oldPrice,
        image: product.image,
        category: product.category,
      },
      quantity
    );
    toast({ title: 'Added to cart', description: `${quantity} × ${product.name}` });
  };

  const handleBuyNow = () => {
    addToCart(
      {
        id: product.id,
        name: product.name,
        price: product.price,
        oldPrice: product.oldPrice,
        image: product.image,
        category: product.category,
      },
      quantity
    );
    window.location.href = '/checkout';
  };

  return (
    <div className="container-ghd py-8 lg:py-12">
      {/* Breadcrumb */}
      <nav className="mb-6 flex items-center gap-1.5 text-sm text-muted-foreground">
        <Link href="/" className="hover:text-brand">Home</Link>
        <ChevronRight className="h-4 w-4" />
        <Link href="/shop" className="hover:text-brand">Shop</Link>
        <ChevronRight className="h-4 w-4" />
        <Link href={`/category/${product.categorySlug}`} className="hover:text-brand">
          {product.category}
        </Link>
        <ChevronRight className="h-4 w-4" />
        <span className="truncate text-foreground">{product.name}</span>
      </nav>

      <div className="grid gap-8 lg:grid-cols-2 lg:gap-12">
        {/* Images */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
        >
          <div className="relative aspect-square overflow-hidden rounded-2xl border border-border bg-muted">
            <Image
              src={product.images[selectedImage]}
              alt={product.name}
              fill
              priority
              sizes="(max-width: 1024px) 100vw, 50vw"
              className="object-cover"
            />
            {discount > 0 && (
              <span className="absolute left-4 top-4 rounded-full bg-red-500 px-3 py-1.5 text-sm font-bold text-white shadow-md">
                -{discount}% OFF
              </span>
            )}
          </div>
          {product.images.length > 1 && (
            <div className="mt-4 flex gap-3">
              {product.images.map((img, idx) => (
                <button
                  key={idx}
                  onClick={() => setSelectedImage(idx)}
                  className={cn(
                    'relative h-20 w-20 overflow-hidden rounded-xl border-2 transition-all',
                    selectedImage === idx
                      ? 'border-brand'
                      : 'border-border hover:border-muted-foreground'
                  )}
                >
                  <Image
                    src={img}
                    alt={`${product.name} ${idx + 1}`}
                    fill
                    sizes="80px"
                    className="object-cover"
                  />
                </button>
              ))}
            </div>
          )}
        </motion.div>

        {/* Details */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          animate={{ opacity: 1, x: 0 }}
          transition={{ duration: 0.5 }}
          className="flex flex-col"
        >
          <Link
            href={`/category/${product.categorySlug}`}
            className="text-sm font-medium uppercase tracking-wide text-gold-500 hover:underline"
          >
            {product.category}
          </Link>
          <h1 className="mt-2 font-display text-3xl font-bold text-foreground sm:text-4xl">
            {product.name}
          </h1>

          <div className="mt-3 flex items-center gap-4">
            <Rating value={product.rating} count={product.reviewCount} size="md" />
            <span className="text-sm text-muted-foreground">
              {product.inStock ? (
                <span className="flex items-center gap-1 font-medium text-green-600 dark:text-green-400">
                  <Check className="h-4 w-4" />
                  In Stock
                </span>
              ) : (
                'Out of stock'
              )}
            </span>
          </div>

          <div className="mt-5 flex items-baseline gap-3">
            <span className="text-3xl font-bold text-brand">
              ${product.price.toFixed(2)}
            </span>
            {product.oldPrice && (
              <>
                <span className="text-xl text-muted-foreground line-through">
                  ${product.oldPrice.toFixed(2)}
                </span>
                <span className="rounded-full bg-red-500/10 px-2.5 py-1 text-sm font-semibold text-red-500">
                  Save ${(product.oldPrice - product.price).toFixed(2)}
                </span>
              </>
            )}
          </div>

          <p className="mt-5 text-base leading-relaxed text-muted-foreground">
            {product.description}
          </p>

          {/* Features */}
          <div className="mt-6">
            <h3 className="mb-3 text-sm font-bold uppercase tracking-wider text-foreground">
              Key Features
            </h3>
            <ul className="grid gap-2">
              {product.features.map((feature, idx) => (
                <li key={idx} className="flex items-start gap-2 text-sm text-muted-foreground">
                  <Check className="mt-0.5 h-4 w-4 flex-shrink-0 text-brand" />
                  {feature}
                </li>
              ))}
            </ul>
          </div>

          {/* Quantity & Actions */}
          <div className="mt-8 flex flex-col gap-4 sm:flex-row sm:items-center">
            <div className="flex items-center rounded-full border border-border">
              <button
                onClick={() => setQuantity((q) => Math.max(1, q - 1))}
                className="flex h-11 w-11 items-center justify-center rounded-l-full transition-colors hover:bg-muted"
                aria-label="Decrease quantity"
              >
                <Minus className="h-4 w-4" />
              </button>
              <span className="w-12 text-center font-semibold tabular-nums">{quantity}</span>
              <button
                onClick={() => setQuantity((q) => q + 1)}
                className="flex h-11 w-11 items-center justify-center rounded-r-full transition-colors hover:bg-muted"
                aria-label="Increase quantity"
              >
                <Plus className="h-4 w-4" />
              </button>
            </div>

            <Button
              onClick={handleAddToCart}
              size="lg"
              variant="outline"
              className="h-12 flex-1 rounded-full"
            >
              <ShoppingCart className="mr-2 h-5 w-5" />
              Add to Cart
            </Button>
            <Button
              onClick={handleBuyNow}
              size="lg"
              className="h-12 flex-1 rounded-full bg-brand hover:bg-brand-600"
            >
              <Zap className="mr-2 h-5 w-5" />
              Buy Now
            </Button>
            <button
              onClick={() => {
                toggleWishlist(product.id);
                toast({
                  title: wished ? 'Removed from wishlist' : 'Added to wishlist',
                  description: product.name,
                });
              }}
              className="flex h-12 w-12 items-center justify-center rounded-full border border-border transition-colors hover:bg-muted"
              aria-label="Toggle wishlist"
            >
              <Heart
                className={cn(
                  'h-5 w-5',
                  wished ? 'fill-red-500 text-red-500' : 'text-foreground'
                )}
              />
            </button>
          </div>

          {/* Trust badges */}
          <div className="mt-8 grid grid-cols-3 gap-4 border-t border-border pt-6">
            {[
              { icon: Package, label: 'Careful Packaging', sub: 'Packed with care' },
              { icon: ShieldCheck, label: 'Secure Payment', sub: '100% protected' },
              { icon: RefreshCw, label: 'Easy Returns', sub: '30-day return policy' },
            ].map((item) => (
              <div key={item.label} className="flex flex-col items-center text-center">
                <item.icon className="mb-1.5 h-6 w-6 text-brand" />
                <p className="text-xs font-semibold text-foreground">{item.label}</p>
                <p className="text-[10px] text-muted-foreground">{item.sub}</p>
              </div>
            ))}
          </div>
        </motion.div>
      </div>

      {/* Related products */}
      {related.length > 0 && (
        <section className="mt-20">
          <SectionHeader
            subtitle="You May Also Like"
            title="Related Products"
            href={`/category/${product.categorySlug}`}
          />
          <div className="grid grid-cols-2 gap-4 sm:grid-cols-3 lg:grid-cols-4">
            {related.map((p, idx) => (
              <ProductCard key={p.id} product={p} index={idx} />
            ))}
          </div>
        </section>
      )}
    </div>
  );
}
