import './globals.css';
import type { Metadata } from 'next';
import { Inter, Playfair_Display } from 'next/font/google';
import { ThemeProvider } from '@/components/providers/theme-provider';
import { CartProvider } from '@/components/providers/cart-provider';
import { Navbar } from '@/components/layout/navbar';
import { Footer } from '@/components/layout/footer';
import { Toaster } from '@/components/ui/toaster';

const inter = Inter({ subsets: ['latin'], variable: '--font-inter' });
const playfair = Playfair_Display({
  subsets: ['latin'],
  variable: '--font-playfair',
});

export const metadata: Metadata = {
  metadataBase: new URL('https://ghdstores.com'),
  title: {
    default: 'GHD Stores | Smart Gadgets • Home Decor • Everyday Essentials',
    template: '%s | GHD Stores',
  },
  description:
    'Shop premium smart gadgets, home decor, and everyday essentials at GHD Stores. Discover mini fans, air humidifiers, smart lights, USB gadgets and more.',
  keywords: [
    'smart gadgets',
    'home decor',
    'mini fans',
    'air humidifiers',
    'smart lights',
    'USB gadgets',
    'mobile accessories',
    'GHD Stores',
    'premium ecommerce',
  ],
  authors: [{ name: 'GHD Stores' }],
  creator: 'GHD Stores',
  openGraph: {
    type: 'website',
    locale: 'en_US',
    url: 'https://ghdstores.com',
    title: 'GHD Stores | Smart Gadgets • Home Decor • Everyday Essentials',
    description:
      'Shop premium smart gadgets, home decor, and everyday essentials at GHD Stores.',
    siteName: 'GHD Stores',
  },
  twitter: {
    card: 'summary_large_image',
    title: 'GHD Stores | Smart Gadgets • Home Decor • Everyday Essentials',
    description:
      'Shop premium smart gadgets, home decor, and everyday essentials at GHD Stores.',
  },
  robots: {
    index: true,
    follow: true,
    googleBot: {
      index: true,
      follow: true,
      'max-image-preview': 'large',
    },
  },
};

export default function RootLayout({
  children,
}: {
  children: React.ReactNode;
}) {
  return (
    <html lang="en" suppressHydrationWarning>
      <body className={`${inter.variable} ${playfair.variable} font-sans antialiased`}>
        <ThemeProvider
          attribute="class"
          defaultTheme="light"
          enableSystem
          disableTransitionOnChange
        >
          <CartProvider>
            <div className="relative flex min-h-screen flex-col">
              <Navbar />
              <main className="flex-1">{children}</main>
              <Footer />
            </div>
            <Toaster />
          </CartProvider>
        </ThemeProvider>
      </body>
    </html>
  );
}
