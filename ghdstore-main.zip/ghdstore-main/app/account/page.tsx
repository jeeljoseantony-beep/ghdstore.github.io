'use client';

import Link from 'next/link';
import { User, Heart, Package, MapPin, LogOut, Settings } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCart } from '@/components/providers/cart-provider';
import { products } from '@/lib/data/products';
import { ProductCard } from '@/components/shared/product-card';

export default function AccountPage() {
  const { wishlist } = useCart();
  const wishlistProducts = products.filter((p) => wishlist.includes(p.id));

  return (
    <div className="container-ghd py-8 lg:py-12">
      <h1 className="mb-8 font-display text-3xl font-bold text-foreground sm:text-4xl">
        My Account
      </h1>

      <div className="grid gap-8 lg:grid-cols-3">
        {/* Sidebar */}
        <aside className="lg:col-span-1">
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="flex items-center gap-4">
              <div className="flex h-16 w-16 items-center justify-center rounded-full bg-brand text-brand-foreground">
                <User className="h-8 w-8" />
              </div>
              <div>
                <p className="font-semibold text-foreground">Welcome back</p>
                <p className="text-sm text-muted-foreground">Guest user</p>
              </div>
            </div>

            <nav className="mt-6 space-y-1">
              {[
                { icon: User, label: 'Profile', active: true },
                { icon: Package, label: 'Orders' },
                { icon: Heart, label: `Wishlist (${wishlist.length})` },
                { icon: MapPin, label: 'Addresses' },
                { icon: Settings, label: 'Settings' },
              ].map((item) => (
                <button
                  key={item.label}
                  className={`flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium transition-colors ${
                    item.active
                      ? 'bg-brand text-brand-foreground'
                      : 'text-foreground hover:bg-muted'
                  }`}
                >
                  <item.icon className="h-4 w-4" />
                  {item.label}
                </button>
              ))}
              <button className="flex w-full items-center gap-3 rounded-lg px-3 py-2.5 text-sm font-medium text-red-500 transition-colors hover:bg-red-500/10">
                <LogOut className="h-4 w-4" />
                Sign Out
              </button>
            </nav>
          </div>
        </aside>

        {/* Main content */}
        <div className="lg:col-span-2 space-y-8">
          {/* Profile */}
          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="mb-4 text-lg font-bold text-foreground">Profile Information</h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" className="mt-1.5" placeholder="Enter your name" />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" className="mt-1.5" placeholder="Enter your name" />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" className="mt-1.5" placeholder="you@example.com" />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" type="tel" className="mt-1.5" placeholder="+1 (000) 000-0000" />
              </div>
            </div>
            <Button className="mt-4 rounded-full bg-brand hover:bg-brand-600">
              Save Changes
            </Button>
          </div>

          {/* Wishlist */}
          <div>
            <h2 className="mb-4 text-lg font-bold text-foreground">
              My Wishlist ({wishlist.length})
            </h2>
            {wishlistProducts.length > 0 ? (
              <div className="grid grid-cols-2 gap-4 sm:grid-cols-3">
                {wishlistProducts.map((product, index) => (
                  <ProductCard key={product.id} product={product} index={index} />
                ))}
              </div>
            ) : (
              <div className="rounded-2xl border border-dashed border-border py-12 text-center">
                <Heart className="mx-auto mb-3 h-10 w-10 text-muted-foreground" />
                <p className="text-sm text-muted-foreground">
                  Your wishlist is empty.{' '}
                  <Link href="/shop" className="font-semibold text-brand hover:underline">
                    Browse products
                  </Link>
                </p>
              </div>
            )}
          </div>
        </div>
      </div>
    </div>
  );
}
