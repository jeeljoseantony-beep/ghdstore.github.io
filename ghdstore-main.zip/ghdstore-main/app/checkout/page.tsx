'use client';

import { useState } from 'react';
import Link from 'next/link';
import Image from 'next/image';
import { motion } from 'framer-motion';
import { CheckCircle, CreditCard, Lock, ArrowLeft } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { useCart } from '@/components/providers/cart-provider';
import { useToast } from '@/hooks/use-toast';

export default function CheckoutPage() {
  const { items, subtotal, totalSavings, clearCart } = useCart();
  const { toast } = useToast();
  const [orderPlaced, setOrderPlaced] = useState(false);
  const [processing, setProcessing] = useState(false);

  const shipping = subtotal > 0 ? 5.99 : 0;
  const tax = subtotal * 0.08;
  const total = subtotal + shipping + tax;

  const handlePlaceOrder = (e: React.FormEvent) => {
    e.preventDefault();
    setProcessing(true);
    setTimeout(() => {
      setProcessing(false);
      setOrderPlaced(true);
      clearCart();
      toast({
        title: 'Order placed successfully!',
        description: 'A confirmation email has been sent.',
      });
    }, 1500);
  };

  if (orderPlaced) {
    return (
      <div className="container-ghd flex flex-col items-center justify-center py-20 text-center">
        <motion.div
          initial={{ scale: 0 }}
          animate={{ scale: 1 }}
          transition={{ type: 'spring', duration: 0.6 }}
          className="mb-6 flex h-24 w-24 items-center justify-center rounded-full bg-green-500/10"
        >
          <CheckCircle className="h-14 w-14 text-green-500" />
        </motion.div>
        <h1 className="font-display text-3xl font-bold text-foreground">
          Order Confirmed!
        </h1>
        <p className="mt-2 max-w-md text-muted-foreground">
          Thank you for your purchase. Your order has been placed successfully.
          A confirmation email with tracking details will arrive shortly.
        </p>
        <div className="mt-6 flex gap-3">
          <Link href="/shop">
            <Button className="rounded-full bg-brand px-8 hover:bg-brand-600">
              Continue Shopping
            </Button>
          </Link>
          <Link href="/">
            <Button variant="outline" className="rounded-full px-8">
              Back to Home
            </Button>
          </Link>
        </div>
      </div>
    );
  }

  if (items.length === 0) {
    return (
      <div className="container-ghd py-20 text-center">
        <h1 className="text-2xl font-bold">Your cart is empty</h1>
        <Link href="/shop" className="mt-4 inline-block text-brand hover:underline">
          Browse products
        </Link>
      </div>
    );
  }

  return (
    <div className="container-ghd py-8 lg:py-12">
      <Link
        href="/cart"
        className="mb-6 inline-flex items-center gap-1.5 text-sm font-semibold text-brand hover:text-gold-500"
      >
        <ArrowLeft className="h-4 w-4" />
        Back to cart
      </Link>

      <h1 className="mb-8 font-display text-3xl font-bold text-foreground sm:text-4xl">
        Checkout
      </h1>

      <form onSubmit={handlePlaceOrder} className="grid gap-8 lg:grid-cols-3">
        {/* Form fields */}
        <div className="space-y-6 lg:col-span-2">
          {/* Shipping info */}
          <div className="rounded-2xl border border-border bg-card p-6">
            <h2 className="mb-4 text-lg font-bold text-foreground">
              Shipping Information
            </h2>
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="firstName">First Name</Label>
                <Input id="firstName" required className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="lastName">Last Name</Label>
                <Input id="lastName" required className="mt-1.5" />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" required className="mt-1.5" />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="address">Address</Label>
                <Input id="address" required className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="city">City</Label>
                <Input id="city" required className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="zip">ZIP Code</Label>
                <Input id="zip" required className="mt-1.5" />
              </div>
              <div className="sm:col-span-2">
                <Label htmlFor="phone">Phone</Label>
                <Input id="phone" type="tel" required className="mt-1.5" />
              </div>
            </div>
          </div>

          {/* Payment info */}
          <div className="rounded-2xl border border-border bg-card p-6">
            <div className="mb-4 flex items-center justify-between">
              <h2 className="text-lg font-bold text-foreground">Payment Details</h2>
              <span className="flex items-center gap-1 text-xs text-muted-foreground">
                <Lock className="h-3.5 w-3.5" />
                Secured
              </span>
            </div>
            <div className="grid gap-4">
              <div>
                <Label htmlFor="cardName">Name on Card</Label>
                <Input id="cardName" required className="mt-1.5" />
              </div>
              <div>
                <Label htmlFor="cardNumber">Card Number</Label>
                <div className="relative mt-1.5">
                  <Input id="cardNumber" placeholder="1234 5678 9012 3456" required className="pr-12" />
                  <CreditCard className="absolute right-3 top-1/2 h-5 w-5 -translate-y-1/2 text-muted-foreground" />
                </div>
              </div>
              <div className="grid grid-cols-2 gap-4">
                <div>
                  <Label htmlFor="expiry">Expiry Date</Label>
                  <Input id="expiry" placeholder="MM/YY" required className="mt-1.5" />
                </div>
                <div>
                  <Label htmlFor="cvv">CVV</Label>
                  <Input id="cvv" placeholder="123" required className="mt-1.5" />
                </div>
              </div>
            </div>
          </div>
        </div>

        {/* Order summary */}
        <div className="lg:col-span-1">
          <div className="sticky top-28 rounded-2xl border border-border bg-card p-6">
            <h2 className="mb-4 text-lg font-bold text-foreground">Your Order</h2>

            <div className="mb-4 max-h-64 space-y-3 overflow-y-auto">
              {items.map((item) => (
                <div key={item.id} className="flex gap-3">
                  <div className="relative h-14 w-14 flex-shrink-0 overflow-hidden rounded-lg bg-muted">
                    <Image
                      src={item.image}
                      alt={item.name}
                      fill
                      sizes="56px"
                      className="object-cover"
                    />
                    <span className="absolute -right-1 -top-1 flex h-5 min-w-5 items-center justify-center rounded-full bg-brand px-1 text-[10px] font-bold text-brand-foreground">
                      {item.quantity}
                    </span>
                  </div>
                  <div className="flex-1">
                    <p className="line-clamp-1 text-sm font-medium text-foreground">
                      {item.name}
                    </p>
                    <p className="text-sm font-semibold text-brand">
                      ${(item.price * item.quantity).toFixed(2)}
                    </p>
                  </div>
                </div>
              ))}
            </div>

            <div className="space-y-2 border-t border-border pt-4 text-sm">
              <div className="flex justify-between">
                <span className="text-muted-foreground">Subtotal</span>
                <span className="font-semibold">${subtotal.toFixed(2)}</span>
              </div>
              {totalSavings > 0 && (
                <div className="flex justify-between text-green-600 dark:text-green-400">
                  <span>Savings</span>
                  <span className="font-semibold">-${totalSavings.toFixed(2)}</span>
                </div>
              )}
              <div className="flex justify-between">
                <span className="text-muted-foreground">Shipping</span>
                <span className="font-semibold">
                  {shipping === 0 ? 'FREE' : `$${shipping.toFixed(2)}`}
                </span>
              </div>
              <div className="flex justify-between">
                <span className="text-muted-foreground">Tax</span>
                <span className="font-semibold">${tax.toFixed(2)}</span>
              </div>
              <div className="border-t border-border pt-2">
                <div className="flex justify-between text-base">
                  <span className="font-bold text-foreground">Total</span>
                  <span className="font-bold text-brand">${total.toFixed(2)}</span>
                </div>
              </div>
            </div>

            <Button
              type="submit"
              size="lg"
              disabled={processing}
              className="mt-6 w-full rounded-full bg-brand hover:bg-brand-600"
            >
              {processing ? 'Processing...' : `Place Order • $${total.toFixed(2)}`}
            </Button>

            <p className="mt-3 text-center text-xs text-muted-foreground">
              By placing your order, you agree to our Terms & Privacy Policy
            </p>
          </div>
        </div>
      </form>
    </div>
  );
}
