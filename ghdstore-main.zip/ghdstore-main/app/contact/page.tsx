'use client';

import { useState } from 'react';
import { motion } from 'framer-motion';
import { Mail, Phone, MapPin, Clock, Send, CheckCircle, Instagram } from 'lucide-react';
import { Button } from '@/components/ui/button';
import { Input } from '@/components/ui/input';
import { Label } from '@/components/ui/label';
import { Textarea } from '@/components/ui/textarea';
import { useToast } from '@/hooks/use-toast';

const contactInfo = [
  {
    icon: MapPin,
    title: 'Address',
    value: 'Manimangalam House',
    sub: 'Manjummel P.O., Eloor, Kerala, India',
  },
  {
    icon: Phone,
    title: 'Phone',
    value: '+91 95448 94106',
    sub: 'Tap to call',
    href: 'tel:+919544894106',
  },
  {
    icon: Mail,
    title: 'Email',
    value: 'Email coming soon',
    sub: 'We\'ll update this shortly',
  },
  {
    icon: Instagram,
    title: 'Instagram',
    value: '@g_h_d_store',
    sub: 'Follow us for updates',
    href: 'https://www.instagram.com/g_h_d_store',
  },
];

export default function ContactPage() {
  const [submitted, setSubmitted] = useState(false);
  const { toast } = useToast();

  const handleSubmit = (e: React.FormEvent) => {
    e.preventDefault();
    setSubmitted(true);
    toast({
      title: 'Message sent!',
      description: 'We will get back to you within 24 hours.',
    });
    setTimeout(() => setSubmitted(false), 4000);
    (e.target as HTMLFormElement).reset();
  };

  return (
    <div className="container-ghd py-8 lg:py-12">
      {/* Header */}
      <div className="mb-12 text-center">
        <p className="mb-2 text-sm font-semibold uppercase tracking-widest text-gold-500">
          Get in Touch
        </p>
        <h1 className="font-display text-4xl font-bold text-foreground sm:text-5xl">
          Contact Us
        </h1>
        <p className="mx-auto mt-3 max-w-xl text-muted-foreground">
          Have a question or need help? Our team is here to assist you with
          anything you need.
        </p>
      </div>

      {/* Contact info cards */}
      <div className="mb-12 grid gap-4 sm:grid-cols-2 lg:grid-cols-4">
        {contactInfo.map((info, index) => {
          const content = (
            <>
              <div className="mx-auto mb-4 flex h-12 w-12 items-center justify-center rounded-xl bg-brand/10 text-brand">
                <info.icon className="h-6 w-6" />
              </div>
              <h3 className="text-sm font-bold uppercase tracking-wider text-foreground">
                {info.title}
              </h3>
              <p className="mt-2 text-sm font-semibold text-foreground">{info.value}</p>
              <p className="mt-1 text-xs text-muted-foreground">{info.sub}</p>
            </>
          );

          const cardClasses =
            'block rounded-2xl border border-border bg-card p-6 text-center transition-all duration-300 hover:-translate-y-1 hover:shadow-lg';

          return (
            <motion.div
              key={info.title}
              initial={{ opacity: 0, y: 20 }}
              whileInView={{ opacity: 1, y: 0 }}
              viewport={{ once: true }}
              transition={{ duration: 0.4, delay: index * 0.08 }}
            >
              {info.href ? (
                <a
                  href={info.href}
                  target={info.href.startsWith('http') ? '_blank' : undefined}
                  rel={info.href.startsWith('http') ? 'noopener noreferrer' : undefined}
                  className={cardClasses}
                >
                  {content}
                </a>
              ) : (
                <div className={cardClasses}>{content}</div>
              )}
            </motion.div>
          );
        })}
      </div>

      {/* Form + Map */}
      <div className="grid gap-8 lg:grid-cols-2">
        {/* Form */}
        <motion.div
          initial={{ opacity: 0, x: -20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="rounded-2xl border border-border bg-card p-6 lg:p-8"
        >
          <h2 className="mb-6 font-display text-2xl font-bold text-foreground">
            Send Us a Message
          </h2>
          <form onSubmit={handleSubmit} className="space-y-4">
            <div className="grid gap-4 sm:grid-cols-2">
              <div>
                <Label htmlFor="name">Name</Label>
                <Input id="name" required className="mt-1.5" placeholder="Your name" />
              </div>
              <div>
                <Label htmlFor="email">Email</Label>
                <Input id="email" type="email" required className="mt-1.5" placeholder="you@example.com" />
              </div>
            </div>
            <div>
              <Label htmlFor="subject">Subject</Label>
              <Input id="subject" required className="mt-1.5" placeholder="How can we help?" />
            </div>
            <div>
              <Label htmlFor="message">Message</Label>
              <Textarea
                id="message"
                required
                rows={5}
                className="mt-1.5 resize-none"
                placeholder="Tell us more..."
              />
            </div>
            <Button
              type="submit"
              size="lg"
              className="w-full rounded-full bg-brand hover:bg-brand-600 sm:w-auto"
            >
              {submitted ? (
                <>
                  <CheckCircle className="mr-2 h-5 w-5" />
                  Message Sent!
                </>
              ) : (
                <>
                  <Send className="mr-2 h-5 w-5" />
                  Send Message
                </>
              )}
            </Button>
          </form>
        </motion.div>

        {/* Business info panel */}
        <motion.div
          initial={{ opacity: 0, x: 20 }}
          whileInView={{ opacity: 1, x: 0 }}
          viewport={{ once: true }}
          transition={{ duration: 0.5 }}
          className="relative overflow-hidden rounded-2xl border border-border bg-gradient-to-br from-brand to-brand-600 p-8 text-brand-foreground"
        >
          <div className="pointer-events-none absolute -right-10 -top-10 h-40 w-40 rounded-full bg-gold-400/10 blur-2xl" />
          <div className="relative">
            <h3 className="font-display text-2xl font-bold">GHD Stores</h3>
            <p className="mt-1 text-sm text-brand-foreground/70">
              Smart Gadgets • Home Decor • Everyday Essentials
            </p>

            <div className="mt-8 space-y-4">
              <div className="flex items-start gap-3">
                <MapPin className="mt-0.5 h-5 w-5 flex-shrink-0 text-gold-400" />
                <div>
                  <p className="text-sm font-semibold">Address</p>
                  <p className="text-sm text-brand-foreground/70">
                    Manimangalam House, Manjummel P.O., Eloor, Kerala, India
                  </p>
                </div>
              </div>

              <a href="tel:+919544894106" className="flex items-start gap-3 transition-opacity hover:opacity-80">
                <Phone className="mt-0.5 h-5 w-5 flex-shrink-0 text-gold-400" />
                <div>
                  <p className="text-sm font-semibold">Phone</p>
                  <p className="text-sm text-brand-foreground/70">+91 95448 94106</p>
                </div>
              </a>

              <div className="flex items-start gap-3">
                <Mail className="mt-0.5 h-5 w-5 flex-shrink-0 text-gold-400" />
                <div>
                  <p className="text-sm font-semibold">Email</p>
                  <p className="text-sm text-brand-foreground/70">Email coming soon</p>
                </div>
              </div>

              <a
                href="https://www.instagram.com/g_h_d_store"
                target="_blank"
                rel="noopener noreferrer"
                className="flex items-start gap-3 transition-opacity hover:opacity-80"
              >
                <Instagram className="mt-0.5 h-5 w-5 flex-shrink-0 text-gold-400" />
                <div>
                  <p className="text-sm font-semibold">Instagram</p>
                  <p className="text-sm text-brand-foreground/70">@g_h_d_store</p>
                </div>
              </a>
            </div>
          </div>
        </motion.div>
      </div>
    </div>
  );
}
