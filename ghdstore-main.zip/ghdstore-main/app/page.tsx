import { HeroSection } from '@/components/sections/hero-section';
import { CategorySection } from '@/components/sections/category-section';
import { FlashDealsSection } from '@/components/sections/flash-deals-section';
import { ProductGridSection } from '@/components/sections/product-grid-section';
import { WhyChooseSection } from '@/components/sections/why-choose-section';
import { ReviewsSection } from '@/components/sections/reviews-section';
import { NewsletterSection } from '@/components/sections/newsletter-section';
import { products } from '@/lib/data/products';

export default function Home() {
  const featured = products.filter((p) => p.isFeatured).slice(0, 8);
  const newArrivals = products.filter((p) => p.isNewArrival);

  return (
    <>
      <HeroSection />
      <CategorySection />
      <FlashDealsSection />
      <ProductGridSection
        title="Featured Products"
        subtitle="Handpicked for You"
        href="/shop"
        products={featured}
      />
      <ProductGridSection
        title="New Arrivals"
        subtitle="Just Landed"
        href="/shop?filter=new"
        products={newArrivals}
        background="muted"
      />
      <WhyChooseSection />
      <ReviewsSection />
      <NewsletterSection />
    </>
  );
}
