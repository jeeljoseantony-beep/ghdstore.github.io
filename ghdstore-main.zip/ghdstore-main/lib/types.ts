export interface Product {
  id: string;
  name: string;
  slug: string;
  category: string;
  categorySlug: string;
  price: number;
  oldPrice?: number;
  rating: number;
  reviewCount: number;
  image: string;
  images: string[];
  description: string;
  features: string[];
  inStock: boolean;
  badge?: string;
  tags: string[];
  isFlashDeal?: boolean;
  isNewArrival?: boolean;
  isFeatured?: boolean;
}

export interface Category {
  id: string;
  name: string;
  slug: string;
  description: string;
  image: string;
  icon: string;
  productCount: number;
}

export interface Review {
  id: string;
  name: string;
  location: string;
  rating: number;
  title: string;
  comment: string;
  avatar: string;
  product: string;
}
