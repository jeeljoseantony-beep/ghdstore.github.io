import type { Category } from '@/lib/types';

export const categories: Category[] = [
  {
    id: 'cat-1',
    name: 'Mini Fans',
    slug: 'mini-fans',
    description: 'Portable cooling solutions for any space',
    image:
      'https://images.pexels.com/photos/39284/macbook-apple-imac-computer-39284.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: 'Wind',
    productCount: 12,
  },
  {
    id: 'cat-2',
    name: 'Air Humidifiers',
    slug: 'air-humidifiers',
    description: 'Breathe easier with smart humidity control',
    image:
      'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: 'Droplets',
    productCount: 9,
  },
  {
    id: 'cat-3',
    name: 'Smart Lights',
    slug: 'smart-lights',
    description: 'Illuminate your home with intelligent lighting',
    image:
      'https://images.pexels.com/photos/1112597/pexels-photo-1112597.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: 'Lightbulb',
    productCount: 15,
  },
  {
    id: 'cat-4',
    name: 'Home Decor',
    slug: 'home-decor',
    description: 'Elevate your space with curated pieces',
    image:
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: 'Home',
    productCount: 20,
  },
  {
    id: 'cat-5',
    name: 'USB Gadgets',
    slug: 'usb-gadgets',
    description: 'Compact tech for everyday convenience',
    image:
      'https://images.pexels.com/photos/39284/macbook-apple-imac-computer-39284.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: 'Usb',
    productCount: 11,
  },
  {
    id: 'cat-6',
    name: 'Mobile Accessories',
    slug: 'mobile-accessories',
    description: 'Everything your phone needs and more',
    image:
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=800',
    icon: 'Smartphone',
    productCount: 18,
  },
];
