import type { Product } from '@/lib/types';

export const products: Product[] = [
  {
    id: 'p1',
    name: 'AeroBreeze Portable Mini Fan',
    slug: 'aerobreeze-portable-mini-fan',
    category: 'Mini Fans',
    categorySlug: 'mini-fans',
    price: 24.99,
    oldPrice: 39.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/4006083/pexels-photo-4006083.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/4006083/pexels-photo-4006083.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/4006084/pexels-photo-4006084.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/4006085/pexels-photo-4006085.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Experience powerful cooling on the go with the AeroBreeze Portable Mini Fan. Featuring three speed settings, a rechargeable battery that lasts up to 12 hours, and whisper-quiet operation.',
    features: [
      'Three adjustable speed settings',
      '12-hour rechargeable battery',
      'Whisper-quiet operation (under 30dB)',
      'USB-C fast charging',
      'Compact and lightweight design',
    ],
    inStock: true,
    badge: '38% OFF',
    tags: ['portable', 'rechargeable', 'cooling'],
    isFlashDeal: true,
    isNewArrival: true,
    isFeatured: true,
  },
  {
    id: 'p2',
    name: 'MistCloud Ultrasonic Humidifier',
    slug: 'mistcloud-ultrasonic_humidifier',
    category: 'Air Humidifiers',
    categorySlug: 'air-humidifiers',
    price: 49.99,
    oldPrice: 79.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/4202326/pexels-photo-4202326.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Transform your indoor air quality with the MistCloud Ultrasonic Humidifier. Features a 4L capacity, essential oil diffuser, and automatic shut-off for peace of mind.',
    features: [
      '4L large capacity tank',
      'Ultrasonic technology for quiet mist',
      'Built-in essential oil diffuser',
      'Auto shut-off when water runs out',
      'Adjustable mist output levels',
    ],
    inStock: true,
    badge: '37% OFF',
    tags: ['aromatherapy', 'quiet', 'large-capacity'],
    isFlashDeal: true,
    isNewArrival: true,
    isFeatured: true,
  },
  {
    id: 'p3',
    name: 'LumenGlow Smart LED Bulb',
    slug: 'lumenglow-smart-led-bulb',
    category: 'Smart Lights',
    categorySlug: 'smart-lights',
    price: 19.99,
    oldPrice: 34.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/1112597/pexels-photo-1112597.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/1112597/pexels-photo-1112597.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1112598/pexels-photo-1112598.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Control your lighting from anywhere with the LumenGlow Smart LED Bulb. 16 million colors, voice control compatible, and energy-efficient design.',
    features: [
      '16 million color options',
      'Voice control with Alexa & Google',
      'App control via WiFi',
      'Energy-efficient LED technology',
      'Customizable schedules and scenes',
    ],
    inStock: true,
    badge: '43% OFF',
    tags: ['wifi', 'voice-control', 'color-changing'],
    isFlashDeal: true,
    isNewArrival: true,
    isFeatured: true,
  },
  {
    id: 'p4',
    name: 'Artisan Ceramic Vase Set',
    slug: 'artisan-ceramic-vase-set',
    category: 'Home Decor',
    categorySlug: 'home-decor',
    price: 39.99,
    oldPrice: 59.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/1571461/pexels-photo-1571461.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Handcrafted ceramic vase set that adds elegance to any room. Each piece is uniquely glazed for a one-of-a-kind finish.',
    features: [
      'Set of 3 handcrafted vases',
      'Unique reactive glaze finish',
      'Food-safe ceramic material',
      'Perfect for fresh or dried flowers',
      'Available in multiple colorways',
    ],
    inStock: true,
    badge: '33% OFF',
    tags: ['handcrafted', 'ceramic', 'decorative'],
    isNewArrival: true,
    isFeatured: true,
  },
  {
    id: 'p5',
    name: 'PowerPort USB-C Hub 7-in-1',
    slug: 'powerport-usb-c-hub-7-in-1',
    category: 'USB Gadgets',
    categorySlug: 'usb-gadgets',
    price: 34.99,
    oldPrice: 54.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/459653/pexels-photo-459653.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/459653/pexels-photo-459653.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/459654/pexels-photo-459654.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Expand your connectivity with the PowerPort 7-in-1 USB-C Hub. Features HDMI 4K, USB 3.0, SD card reader, and 100W power delivery.',
    features: [
      '7 ports in one compact hub',
      '4K HDMI output',
      '100W power delivery passthrough',
      'USB 3.0 high-speed data transfer',
      'SD and microSD card reader',
    ],
    inStock: true,
    badge: '36% OFF',
    tags: ['connectivity', '4k', 'multiport'],
    isFlashDeal: true,
    isFeatured: true,
  },
  {
    id: 'p6',
    name: 'FlexiCharge Wireless Phone Stand',
    slug: 'flexicharge-wireless-phone-stand',
    category: 'Mobile Accessories',
    categorySlug: 'mobile-accessories',
    price: 29.99,
    oldPrice: 49.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=800',
      'https://images.pexels.com/photos/404281/pexels-photo-404281.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Charge your phone in style with the FlexiCharge Wireless Stand. 15W fast charging, adjustable angle, and a sleek aluminum finish.',
    features: [
      '15W fast wireless charging',
      'Adjustable viewing angle',
      'Premium aluminum build',
      'Qi-compatible with all devices',
      'LED charging indicator',
    ],
    inStock: true,
    badge: '40% OFF',
    tags: ['wireless-charging', 'fast-charge', 'aluminum'],
    isNewArrival: true,
    isFeatured: true,
  },
  {
    id: 'p7',
    name: 'BreezeMax Desk Oscillating Fan',
    slug: 'breezemax-desk-oscillating-fan',
    category: 'Mini Fans',
    categorySlug: 'mini-fans',
    price: 32.99,
    oldPrice: 52.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/4006083/pexels-photo-4006083.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/4006083/pexels-photo-4006083.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Keep your workspace cool with the BreezeMax Desk Fan. Oscillating airflow, 4 speed modes, and a timer function.',
    features: [
      '90-degree oscillation',
      '4 speed modes',
      'Built-in timer (1-8 hours)',
      'Remote control included',
      'Energy-efficient motor',
    ],
    inStock: true,
    badge: '38% OFF',
    tags: ['desk', 'oscillating', 'remote'],
    isFeatured: true,
  },
  {
    id: 'p8',
    name: 'PureAir Aroma Diffuser Pro',
    slug: 'pureair-aroma-diffuser-pro',
    category: 'Air Humidifiers',
    categorySlug: 'air-humidifiers',
    price: 42.99,
    oldPrice: 69.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/4202325/pexels-photo-4202325.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Premium aroma diffuser with 7-color ambient lighting, timer settings, and a 500ml capacity for all-day use.',
    features: [
      '500ml large capacity',
      '7-color LED ambient lighting',
      'Timer with auto shut-off',
      'Whisper-quiet operation',
      'Premium wood-grain finish',
    ],
    inStock: true,
    badge: '39% OFF',
    tags: ['aromatherapy', 'ambient-light', 'large-capacity'],
    isNewArrival: true,
    isFeatured: true,
  },
  {
    id: 'p9',
    name: 'HueStrip Smart LED Light Bar',
    slug: 'huestrip-smart-led-light-bar',
    category: 'Smart Lights',
    categorySlug: 'smart-lights',
    price: 27.99,
    oldPrice: 44.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/1112597/pexels-photo-1112597.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/1112597/pexels-photo-1112597.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Transform any room with the HueStrip Smart Light Bar. Music sync, app control, and 16 million colors.',
    features: [
      'Music sync technology',
      '16 million colors',
      'App and voice control',
      'Mountable anywhere',
      'Energy-efficient design',
    ],
    inStock: true,
    badge: '38% OFF',
    tags: ['music-sync', 'color-changing', 'app-control'],
    isFlashDeal: true,
    isNewArrival: true,
  },
  {
    id: 'p10',
    name: 'Nordic Wooden Wall Clock',
    slug: 'nordic-wooden-wall-clock',
    category: 'Home Decor',
    categorySlug: 'home-decor',
    price: 45.99,
    oldPrice: 69.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/1571460/pexels-photo-1571460.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Minimalist Nordic-design wall clock crafted from sustainable wood. Silent quartz movement and elegant numerals.',
    features: [
      'Sustainable wood construction',
      'Silent quartz movement',
      '12-inch diameter',
      'Minimalist Scandinavian design',
      'Easy wall mounting',
    ],
    inStock: true,
    badge: '34% OFF',
    tags: ['minimalist', 'wooden', 'silent'],
  },
  {
    id: 'p11',
    name: 'DataSync USB-C Cable Braided',
    slug: 'datasync-usb-c-cable-braided',
    category: 'USB Gadgets',
    categorySlug: 'usb-gadgets',
    price: 12.99,
    oldPrice: 22.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/459653/pexels-photo-459653.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/459653/pexels-photo-459653.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Durable braided USB-C cable with 100W power delivery and high-speed data transfer. Tangle-free nylon design.',
    features: [
      '100W power delivery',
      'High-speed data transfer (480Mbps)',
      'Nylon braided for durability',
      '6-foot length',
      'Universal USB-C compatibility',
    ],
    inStock: true,
    badge: '43% OFF',
    tags: ['durable', 'fast-charge', 'braided'],
    isFlashDeal: true,
  },
  {
    id: 'p12',
    name: 'ArmorShield Phone Case Pro',
    slug: 'armorshield-phone-case-pro',
    category: 'Mobile Accessories',
    categorySlug: 'mobile-accessories',
    price: 18.99,
    oldPrice: 29.99,
    rating: 0,
    reviewCount: 0,
    image:
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=800',
    images: [
      'https://images.pexels.com/photos/404280/pexels-photo-404280.jpeg?auto=compress&cs=tinysrgb&w=800',
    ],
    description:
      'Military-grade phone protection with a slim profile. Drop-tested to 15 feet with raised bezel screen protection.',
    features: [
      'Military-grade drop protection',
      'Slim 1.2mm profile',
      'Raised bezel screen protection',
      'Anti-yellowing TPU material',
      'Wireless charging compatible',
    ],
    inStock: true,
    badge: '37% OFF',
    tags: ['protective', 'slim', 'military-grade'],
  },
];

export function getProductBySlug(slug: string): Product | undefined {
  return products.find((p) => p.slug === slug);
}

export function getProductsByCategory(categorySlug: string): Product[] {
  return products.filter((p) => p.categorySlug === categorySlug);
}

export function getRelatedProducts(product: Product, limit = 4): Product[] {
  return products
    .filter((p) => p.id !== product.id && p.categorySlug === product.categorySlug)
    .slice(0, limit);
}
